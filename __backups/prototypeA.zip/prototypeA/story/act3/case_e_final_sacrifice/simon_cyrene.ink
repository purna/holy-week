// ============================================================
// CHARACTER: Simon of Cyrene
// ACT: Act III
// CASE: The Road to Golgotha
// CASE ID: via_dolorosa
// SOURCE: ORPHAN FILE (not referenced in any case file)
// ------------------------------------------------------------
// ============================================================
//

-> start
=== start ===
My friend, I was just walking home from the quarry when they seized me. I was carrying my own cross to the place of the skull. I did not know his name then.
* [They forced you to carry the cross.] -> forced
* [What was He like?] -> his_words
=== forced ===
The soldiers saw I was from Cyrene — a Greek-speaking Jew from North Africa. They needed someone strong enough to carry that beam when the Nazarene collapsed from blood loss and exhaustion. They didn't ask. They drafted.
* [And you carried it.] -> his_words
=== his_words ===
I heard Him speak to the women along the way. "Daughters of Jerusalem, do not weep for me." Not a word of anger. Not a curse. He spoke to them as if He were already beyond their grief.
* [He was heading to His death.] -> closing
=== closing ===
I set the cross down at Golgotha and I left. I did not know who He was. But I have thought about those words every day since.
-> DONE
